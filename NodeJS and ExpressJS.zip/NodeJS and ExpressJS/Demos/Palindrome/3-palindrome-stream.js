var Transform = require('stream').Transform;
var util = require('util');

module.exports = {
    CreateWordList: CreateWordList,
    FindPalindromes: FindPalindromes
};

/////////////////////////////////////////
//  CreateWordList Stream
/////////////////////////////////////////
function CreateWordList(options, wordSize) {
    //Transform.call(this,{ "objectMode": true });
    Transform.call(this);
    this.wordSize = wordSize;
}
util.inherits(CreateWordList, Transform);
CreateWordList.prototype._transform = function (chunk, encoding, callback) {

    if (!chunk) {
        this.push(null);
        callback();
    }

    var words = [];
    var word;
    var lines = chunk.toString().split('\n');
    do {
        words = words.concat(lines.pop().split(' '));
    } while (lines.length > 0)

    do {
        word = words.pop();
        if (word.length >= this.wordSize)
            this.push(word);
    } while (words.length > 0)


    callback();
};

/////////////////////////////////////////
//  FindPalindromes Stream
/////////////////////////////////////////
function FindPalindromes(option) {
    Transform.call(this, { "objectMode": true });
}
util.inherits(FindPalindromes, Transform);
FindPalindromes.prototype._transform = function (word, encode, callback) {
    if (!word) {
        callback();
    }
    word = word.toString();

    if (word == word.split("").reverse().join("")) {
        this.push(word + '\n');
    }

    callback();
};