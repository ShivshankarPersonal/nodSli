var request = require("request");

module.exports = function(url) {

    createWordList(url, function (data) {
        console.log('createWordList');
        filterWordList(data, function (words) {
            console.log('filterWordList');
            findPalindromes(words, function (palindromes) {
                console.log('findPalindromes');
                printPalindrome(palindromes, function (palindrome) {
                    console.log(palindrome);
                })
            })
        })
    });

    ///////////// JS Code ////////////////
    function createWordList(url, cb) {
        request(url, function (error, respones, body) {
            cb(body);
        });
    }

    function filterWordList(string, cb) {
        setImmediate(function () {
            var words = [];
            var lines = string.split('\n');
            do {
                words = words.concat(lines.pop().split(' '));
            } while (lines.length > 0)
            cb(words);
        });
    }

    function findPalindromes(words, cb) {
        var palindromes = [];
        var item = {};

        setImmediate(function findPldrm() {
            var start = +new Date();
            do {
                item = words.shift();
                if (isPalindrome(item)) {
                    console.log(item);
                    palindromes.push(item)
                }
            } while (words.length > 0 && (+new Date() - start < 100));

            if (words.length > 0) {
                setImmediate(findPldrm);
            } else {
                cb(palindromes);
            }
        });

    }

    function printPalindrome(palindromes, cb) {
        for (var i = 0; i < palindromes.length; i++) {
            console.log(palindromes[i])
        }
    }

    function isPalindrome(word) {
        if (word.length > 3) {
            return word == word.split("").reverse().join("");
        }
        return false;
    }
};