var p1 = require('./1-palindrome-callback');
var p2 = require('./2-palindrome-event');
var p3 = require('./3-palindrome-stream');
var http = require('http');
var fs = require('fs');
var file = __dirname + '\\Palindrome.txt';

////////////////////////////////////////
//  Callback Demo
////////////////////////////////////////

//p1('http://en.wikipedia.org/wiki/Palindrome');

////////////////////////////////////////
//  Event Demo
////////////////////////////////////////

//var p = new p2.Palindrome('http://en.wikipedia.org/wiki/Palindrome');
//
//p.on('createWordList', function(data){
//    console.log('createWordList');
//});


////////////////////////////////////////
//  Stream Demo
////////////////////////////////////////
fs.createReadStream(file)
    .pipe(new p3.CreateWordList(null,3))
    .pipe(new p3.FindPalindromes())
    .pipe(process.stdout);



