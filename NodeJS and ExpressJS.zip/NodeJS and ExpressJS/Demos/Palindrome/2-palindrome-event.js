var request = require("request");
var EventEmitter = require('events').EventEmitter;
var util = require('util');

exports.Palindrome = Palindrome;

function Palindrome(url) {
    var _self = this;
    EventEmitter.call(_self);

    this.createWordList(url, function (data) {
       _self.emit('createWordList');
        _self.filterWordList(data, function (words) {
            _self.emit('filterWordList');
            _self.findPalindromes(words, function (palindromes) {
                _self.emit('findPalindromes');
                _self.printPalindrome(palindromes, function (palindrome) {
                    _self.emit('palindrome',palindrome);
                })
            })
        })
    });
};

util.inherits(Palindrome, EventEmitter);

Palindrome.prototype.createWordList = function (url, cb) {
    request(url, function (error, respones, body) {
        cb(body);
    });
}
Palindrome.prototype.filterWordList = function (string, cb) {
    setImmediate(function () {
        var words = [];
        var lines = string.split('\n');
        do {
            words = words.concat(lines.pop().split(' '));
        } while (lines.length > 0)
        cb(words);
    });
}
Palindrome.prototype.findPalindromes = function (words, cb) {
    var palindromes = [];
    var item = {};
    var _self = this;
    setImmediate(function findPldrm() {
        var start = +new Date();
        do {
            item = words.shift();
            if (_self.isPalindrome(item)) {
                console.log(item);
                palindromes.push(item)
            }
        } while (words.length > 0 && (+new Date() - start < 100));

        if (words.length > 0) {
            setImmediate(findPldrm);
        } else {
            cb(palindromes);
        }
    });

}
Palindrome.prototype.printPalindrome = function (palindromes, cb) {
    for (var i = 0; i < palindromes.length; i++) {
        console.log(palindromes[i])
    }
}
Palindrome.prototype.isPalindrome = function (word) {
    if (word.length > 3) {
        return word == word.split("").reverse().join("");
    }
    return false;
}